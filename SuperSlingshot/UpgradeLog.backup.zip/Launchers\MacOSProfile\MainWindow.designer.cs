namespace SuperSlingshot
{
	[global::Foundation.Register ("MainWindow")]
	public partial class MainWindow
	{
	}
}
