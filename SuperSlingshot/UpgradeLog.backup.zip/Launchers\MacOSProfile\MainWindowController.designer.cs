namespace SuperSlingshot
{
	[global::Foundation.Register ("MainWindowController")]
	public partial class MainWindowController
	{
	}
}
