using System;
using Foundation;
using UIKit;
using System.Drawing;

namespace SuperSlingshot
{
    public class Program
    {
        static void Main(string[] args)
        {
            UIApplication.Main(args, null, "AppDelegate");
        }
    }
}

