﻿namespace SuperSlingshot.Enums
{
    public enum SwitchEnum
    {
        OFF,
        ON,
        INDETERNINATE
    }
}
