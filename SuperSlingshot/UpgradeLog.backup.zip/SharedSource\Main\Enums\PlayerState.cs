﻿namespace SuperSlingshot.Enums
{
    public enum PlayerState
    {
        Prepared,
        InTheAir,
        Stamped,
        Dead
    }
}
