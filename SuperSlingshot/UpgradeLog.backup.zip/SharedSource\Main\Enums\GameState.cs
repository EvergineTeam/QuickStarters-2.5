﻿namespace SuperSlingshot.Enums
{
    public enum GameState
    {
        Intro,
        LevelSelection,
        Play,
        Pause,
        GameOver
    }
}
