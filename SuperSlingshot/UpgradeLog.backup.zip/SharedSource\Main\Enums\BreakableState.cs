﻿namespace SuperSlingshot.Enums
{
    public enum BreakableState
    {
        NORMAL,
        DAMAGED,
        DEAD
    }
}
