namespace OrbitRabbits
{
	[global::Foundation.Register ("MainWindowController")]
	public partial class MainWindowController
	{
	}
}
