using System;
using Foundation;
using UIKit;
using System.Drawing;

namespace OrbitRabbits
{
    public class Program
    {
        static void Main(string[] args)
        {
            UIApplication.Main(args, null, "AppDelegate");
        }
    }
}

