﻿using SuperSlingshot.Enums;

namespace SuperSlingshot.Managers
{
    public class LevelScore
    {
        public StarScoreEnum StarScore { get; set; }

        public int Points { get; set; }

        public int Gems { get; set; }
    }
}
