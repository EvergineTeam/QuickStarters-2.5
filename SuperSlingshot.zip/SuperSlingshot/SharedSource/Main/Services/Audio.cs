﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SlingshotRampage.Services
{
    public class Audio
    {
        public enum Music : int
        {
            backgroundmusic_mp3
        }

        public enum Sfx : int
        {
            Launch_wav,
            Crash_wav,
            Rubber_wav
        }
    }
}
