﻿namespace SuperSlingshot.Enums
{
    public enum BreakableType
    {
        WOOD,
        STONE,
        GLASS,
        METAL
    }
}
