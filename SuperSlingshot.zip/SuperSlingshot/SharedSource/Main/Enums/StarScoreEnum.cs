﻿namespace SuperSlingshot.Enums
{
    public enum StarScoreEnum
    {
        NONE,
        ONE,
        TWO,
        THREE
    }
}
