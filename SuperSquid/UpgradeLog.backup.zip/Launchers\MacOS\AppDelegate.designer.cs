namespace SuperSquid
{
	[global::Foundation.Register ("AppDelegate")]
	public partial class AppDelegate
	{
	}
}
