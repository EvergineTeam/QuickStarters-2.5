using System;
using Foundation;
using UIKit;
using System.Drawing;

namespace SuperSquid
{
    public class Program
    {
        static void Main(string[] args)
        {
            UIApplication.Main(args, null, "AppDelegate");
        }
    }
}

